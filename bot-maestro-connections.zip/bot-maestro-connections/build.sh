#!/bin/bash

zip -r "bot-maestro-connections.zip" * -x "bot-maestro-connections.zip"