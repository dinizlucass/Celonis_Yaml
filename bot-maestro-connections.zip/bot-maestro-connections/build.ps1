$exclude = @("venv", "bot-maestro-connections.zip")
$files = Get-ChildItem -Path . -Exclude $exclude
Compress-Archive -Path $files -DestinationPath "bot-maestro-connections.zip" -Force